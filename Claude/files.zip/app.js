/* Sentinel: presentation-layer interactions (simulated detection) */
(function () {
  'use strict';
  const form = document.getElementById('scan-form');
  const input = document.getElementById('url-input');
  const errorEl = document.getElementById('form-error');
  const scoreEl = document.getElementById('gauge-score');
  const markerEl = document.getElementById('gauge-needle');
  const verdictEl = document.getElementById('result-verdict');
  const explanationEl = document.getElementById('result-explanation');
  const chainEl = document.getElementById('cert-chain');
  const rows = {
    reputation: document.getElementById('check-reputation'),
    headers: document.getElementById('check-headers'),
    certificate: document.getElementById('check-certificate'),
    threat: document.getElementById('check-threat-intel'),
  };
  const STATUS = { ok: 'Pass', warn: 'Warning', bad: 'Fail' };

  // Single source of truth: score (0-100) -> verdict + badge class.
  function scoreToVerdict(score) {
    if (score <= 33) return { verdict: 'Safe', badge: 'badge--safe' };
    if (score <= 66) return { verdict: 'Suspicious', badge: 'badge--suspicious' };
    return { verdict: 'Malicious', badge: 'badge--malicious' };
  }

  // Deterministic simulated score (no network, no real CA).
  function computeScore(url) {
    let score = 0;
    const reasons = [];
    const add = (n, r) => { score += n; reasons.push(r); };
    const p = new URL(url);
    const host = p.hostname;
    if (p.protocol !== 'https:') add(30, 'connection is not encrypted (HTTP)');
    if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) add(25, 'uses an IP address instead of a domain');
    if (p.username) add(20, 'contains credentials in the address');
    if (host.includes('-')) add(15, 'hyphenated domain name');
    if (/xn--/.test(host)) add(15, 'internationalised (punycode) domain');
    if (url.length > 75) add(10, 'unusually long address');
    const words = ['login', 'verify', 'secure', 'account', 'paypal', 'bank', 'update', 'signin', 'webscr', 'confirm']
      .filter((k) => host.includes(k) || p.pathname.toLowerCase().includes(k));
    if (words.length) add(10 * words.length, 'credential-related keywords (' + words.join(', ') + ')');
    if (host.split('.').length - 1 >= 4) add(10, 'deep subdomain chain');
    return { score: Math.min(100, score), reasons, https: p.protocol === 'https:' };
  }

  function setRow(row, status, detail) {
    row.className = 'check check--' + status;
    row.querySelector('.status').textContent = STATUS[status];
    row.querySelector('.detail').textContent = detail;
  }

  function render(r) {
    const v = scoreToVerdict(r.score);
    scoreEl.textContent = r.score;
    markerEl.style.left = r.score + '%';
    verdictEl.textContent = v.verdict;
    verdictEl.className = 'badge ' + v.badge;
    explanationEl.textContent = r.reasons.length
      ? 'Contributing factors: ' + r.reasons.join('; ') + '.'
      : 'No strong risk signals were detected.';
    const level = r.score <= 33 ? 'ok' : r.score <= 66 ? 'warn' : 'bad';
    setRow(rows.reputation, level, r.reasons.length ? 'Signals: ' + r.reasons.slice(0, 2).join('; ') + '.' : 'No known-bad listings or suspicious patterns.');
    setRow(rows.headers, r.https ? 'warn' : 'bad', r.https ? 'Missing strict-transport-security header (simulated).' : 'No transport encryption, so headers cannot protect the session.');
    setRow(rows.certificate, !r.https ? 'bad' : level === 'bad' ? 'bad' : 'ok', !r.https ? 'No certificate: the site does not use HTTPS.' : level === 'bad' ? 'Chain incomplete; unrecognised intermediate (simulated).' : 'Chain complete; transparency log entry present (simulated).');
    setRow(rows.threat, level === 'bad' ? 'bad' : level === 'warn' ? 'warn' : 'ok', level === 'ok' ? 'No community reports (simulated).' : 'Matches patterns in recent community reports (simulated).');
    chainEl.textContent = !r.https ? 'Not applicable' : level === 'bad' ? 'Incomplete' : 'Complete';
  }

  form.addEventListener('submit', function (evt) {
    evt.preventDefault();
    errorEl.textContent = '';
    let url = input.value.trim();
    if (!url) { errorEl.textContent = 'Enter a website address.'; input.focus(); return; }
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    try { render(computeScore(url)); }
    catch (e) { errorEl.textContent = 'That does not look like a valid website address.'; input.focus(); }
  });

  render({ score: 0, reasons: [], https: true });
  rows.reputation.querySelector('.detail').textContent = 'Submit a link to begin.';
  rows.headers.querySelector('.detail').textContent = 'Submit a link to begin.';
  rows.certificate.querySelector('.detail').textContent = 'Submit a link to begin.';
  rows.threat.querySelector('.detail').textContent = 'Submit a link to begin.';
})();
