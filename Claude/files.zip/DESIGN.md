# DESIGN.md: Sentinel visual design system

## Intent
Sentinel should read like a public-sector service: plain, structured, accessible, trustworthy. Authority comes from clear hierarchy, not decoration.

## Visual mode
Civic light theme. Navy masthead, white content, one blue accent for actions. Red, amber and green appear only for verdicts and always with a text label. Meets WCAG AA contrast.

## Tokens (source of truth: assets/css/style.css)
- Colors: brand #112e51, accent #005ea2, base #f5f7fa, surface #ffffff, border #c5ced9, text #1b1b1b, muted #4b5563; danger #b50909, warning #7a5200, success #1e6b2b.
- Type: one sans stack (Source Sans 3, Segoe UI, system fallbacks); monospace only for URLs, hashes and fingerprints. Base 17px, line-height 1.6.
- Radius 4px. Max width 1040px. Spacing scale 0.5 to 4.5rem.

## Components
Buttons (primary), panel, method card, text input, verdict badge, results table, threat feed table, definition list for certificate facts, numbered steps.

## Rules (no AI slop)
- No gradients except the verdict meter. No purple, neon, blobs, glass, glow or soft grey shadows.
- No ALL-CAPS labels, middle-dot meta strings, or arrows on links. Sentence case throughout.
- No emojis, stock icons on every card, or invented metrics. Sample data is labelled as sample.
- Do not imitate any real government emblem, flag or agency name.
- Visible focus ring, skip link, semantic tables, status never conveyed by color alone.
- Body text line length under 75 characters.
