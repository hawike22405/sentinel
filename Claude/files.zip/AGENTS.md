# AGENTS.md — Sentinel cross-agent rules

This file establishes build/test commands, directory structure, and component allow-lists so every agent and tool works from the same contract. Place a bare `@AGENTS.md` import at the top of CLAUDE.md to load these rules on every turn.

## Directory structure
```
/sentinel
  PRD.md                 # product requirements
  DESIGN.md              # visual design system & tokens
  AGENTS.md              # this file
  CLAUDE.md              # persistent tool context
  docs/
    architecture.md      # system boundaries, patterns, integrations, state
    code-standards.md    # reusable patterns & utilities
  public/
    llms.txt             # documentation index
  context/
    progress.md          # session memory (slices, bugs, next steps)
  index.html             # presentation layer (vibe-coded website)
  assets/css/style.css   # design tokens + component styles
  assets/js/app.js       # vanilla JS interactions
  scripts/               # verification oracles (gate checks)
```

## Build / test commands
- `node scripts/gate-lint.mjs GATES.md` — lint the completion ledger (must print `LINT OK`).
- `node scripts/verify-foundation.mjs` — verify all `.md` foundation files are complete.
- `node scripts/verify-website.mjs` — verify the website structure and assets.
- `node scripts/verify-all.mjs` — full re-verification (lint + foundation + website).
- Open `index.html` directly in a browser to review the presentation layer (no build step, no dev server).

## Component allow-list (UI primitives only)
Buttons: primary, danger, outline (sizes sm/md/lg).
Cards: panel, method card. Tables: results table, threat feed table.
Inputs: text/url input with focus ring.
Badges: safe / suspicious / malicious verdict chips.
No other component types may be invented without updating this list and DESIGN.md.

## Styling rules
- Use CSS custom properties from `assets/css/style.css` only; no raw hex values in markup or JS.
- Responsive. Max content width 1040px, centered. Tables and definition lists are allowed for results and feeds.
- Light civic theme only (white surfaces, navy masthead). No dark-mode toggle.
- Respect `prefers-reduced-motion`; no non-user-triggered motion.

## Prohibited patterns (AI slop)
- Purple/violet gradients, acid-green neon, generic blobs.
- Centered hero + three identical rounded cards + soft grey shadows.
- ALL-CAPS labels, middle-dot meta strings, `→` on every link.
- Lorem ipsum, tiny fake body copy, invented metrics dashboards.
